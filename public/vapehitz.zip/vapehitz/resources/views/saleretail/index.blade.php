@extends('layouts.app')

@section('title', 'Vapehitz')

@section('content')
<a href="/saleretail/create" class="btn btn-success">Tambah Penjualan Barang</a>
@endsection