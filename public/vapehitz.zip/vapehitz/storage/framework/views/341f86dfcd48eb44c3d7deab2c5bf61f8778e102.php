<?php $__env->startSection('title', 'Vapehitz'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head">
                <div class="nk-block-between g-3">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">
                            <?php if($centralSale->status == 'approved'): ?>
                            <em class="icon ni ni-check-circle-fill text-success"></em>
                            <?php elseif($centralSale->status == 'rejected'): ?>
                            <em class="icon ni ni-cross-circle-fill text-danger"></em>
                            <?php else: ?>
                            <em class="icon ni ni-clock-fill text-warning"></em>
                            <?php endif; ?>
                            Penjualan No. <strong class="text-primary small">#<?php echo e($centralSale->code); ?></strong>
                        </h3>
                        <div class="nk-block-des text-soft">
                            <ul class="list-inline">
                                <li>Created At: <span class="text-base"><?php echo e(\Carbon\Carbon::parse($centralSale->created_at)->isoFormat('LLL')); ?></span></li>
                                <li>Created By:
                                    <?php if($centralSale->createdBy !== null): ?>
                                    <span class="text-base"><?php echo e($centralSale->createdBy->name); ?></span>
                                    <?php else: ?>
                                    <span class="text-base">-</span>
                                    <?php endif; ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="nk-block-head-content">
                        <a href="/central-sale" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em class="icon ni ni-arrow-left"></em><span>Back</span></a>
                        <a href="html/invoice-list.html" class="btn btn-icon btn-outline-light bg-white d-inline-flex d-sm-none"><em class="icon ni ni-arrow-left"></em></a>
                    </div>
                </div>
            </div><!-- .nk-block-head -->
            <div class="nk-block">
                <div class="invoice">
                    <div class="invoice-action">
                        <a class="btn btn-icon btn-lg btn-white btn-dim btn-outline-primary" href="/central-sale/print/<?php echo e($centralSale->id); ?>" target="_blank"><em class="icon ni ni-printer-fill"></em></a>
                    </div><!-- .invoice-actions -->
                    <div class="invoice-wrap">
                        <div class="invoice-brand text-center">
                            <img src="./images/logo-dark.png" srcset="./images/logo-dark2x.png 2x" alt="">
                        </div>
                        <div class="invoice-head">
                            <div class="invoice-contact">
                                <!-- <span class="overline-title">Invoice To</span> -->
                                <div class="invoice-contact-info">
                                    <?php if($centralSale->customer !== null): ?>
                                    <h4 class="title"><?php echo e($centralSale->customer->name); ?></h4>
                                    <ul class="list-plain">
                                        <li><em class="icon ni ni-map-pin-fill"></em><span><?php echo e($centralSale->customer->address); ?></span></li>
                                        <li><em class="icon ni ni-call-fill"></em><span><?php echo e($centralSale->customer->handphone); ?></span></li>
                                    </ul>
                                    <?php else: ?>
                                    <h4 class="title text-danger">Deleted Customer</h4>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="invoice-desc">
                                <!-- <h3 class="title">Invoice</h3> -->
                                <ul class="list-plain">
                                    <li class="invoice-id"><span>Sale ID</span>:<span><?php echo e($centralSale->code); ?></span></li>
                                    <li class="invoice-date"><span>Date</span>:<span><?php echo e(\Carbon\Carbon::parse($centralSale->date)->isoFormat('L')); ?></span></li>
                                    <?php if($centralSale->shipment !== null): ?>
                                    <li class="invoice-date"><span>Shipment</span>:<span><?php echo e($centralSale->shipment->name); ?></span></li>
                                    <?php endif; ?>
                                    <li class="invoice-date"><span>Penerima</span>:<span><?php echo e($centralSale->recipient); ?></span></li>
                                    <li class="invoice-date"><span>Alamat Penerima</span>:<span><?php echo e($centralSale->address_recipient); ?></span></li>
                                    <li class="invoice-date"><span>Due Date</span>:<span><?php echo e(\Carbon\Carbon::parse($centralSale->due_date)->isoFormat('L')); ?></span></li>
                                </ul>
                            </div>
                        </div><!-- .invoice-head -->
                        <div class="invoice-bills">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th class="w-150px">Item ID</th>
                                            <th class="w-60">Description</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th>Free</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $centralSale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product->code); ?></td>
                                            <td>
                                                <?php echo e($product->name); ?>

                                            </td>
                                            <td><?php echo e(number_format($product->pivot->price, 0, ',', '.')); ?></td>
                                            <td><?php echo e($product->pivot->quantity); ?></td>
                                            <td><?php echo e($product->pivot->free); ?></td>
                                            <td><?php echo e(number_format($product->pivot->amount, 0, ',', '.')); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">Total Amount</td>
                                            <td><?php echo e(number_format($centralSale->total_cost, 0, ',', '.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">Diskon</td>
                                            <td>
                                                <?php if($centralSale->discount !== null): ?>
                                                <?php if($centralSale->discount_type == 'nominal'): ?>
                                                <?php echo e(number_format(0 - $centralSale->discount, 0, ',', '.')); ?>

                                                <?php else: ?>
                                                <?php
                                                $discount = $centralSale->total_cost * ($centralSale->discount / 100)
                                                ?>
                                                <?php echo e(number_format(0 - $discount, 0, ',', '.')); ?>

                                                <?php endif; ?>
                                                <?php else: ?>
                                                0
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">Subtotal</td>
                                            <td><?php echo e(number_format($centralSale->subtotal, 0, ',', '.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">Biaya Kirim</td>
                                            <td><?php echo e(number_format($centralSale->shipping_cost, 0, ',', '.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">
                                                Biaya Lainnya
                                                <?php if($centralSale->detail_other_cost !== null): ?>
                                                <?php echo e('(' . $centralSale->detail_other_cost . ')'); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(number_format($centralSale->other_cost, 0, ',', '.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">Deposit Pelanggan</td>
                                            <td><?php echo e(number_format($centralSale->customer_deposit, 0, ',', '.')); ?></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2"></td>
                                            <td colspan="3">Total</td>
                                            <td><?php echo e(number_format($centralSale->net_total, 0, ',', '.')); ?></td>
                                        </tr>
                                    </tfoot>
                                </table>
                                <!-- <div class="nk-notes ff-italic fs-12px text-soft"> Invoice was created on a computer and is valid without the signature and seal. </div> -->
                            </div>
                        </div><!-- .invoice-bills -->
                    </div><!-- .invoice-wrap -->
                </div><!-- .invoice -->
            </div><!-- .nk-block -->
            <div class="row mt-4">
                <div class="col-lg-6 col-sm-12">
                    <div class="card card-bordered">
                        <div class="card-inner-group">
                            <div class="card-inner card-inner-md">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Riwayat Pembayaran</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="card-inner">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Kode Transaksi</th>
                                                <th>Metode</th>
                                                <th class="text-right">Jumlah</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $subTotal = 0; ?>
                                            <?php if(count($transactions) == 0): ?>
                                            <tr>
                                                <td colspan="4" class="text-center"><em class="text-soft">Belum ada pembayaran</em></td>
                                            </tr>
                                            <?php else: ?>
                                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(date_format(date_create($transaction->date), "d/m/Y")); ?></td>
                                                <td><a href="/central-sale-transaction/show/<?php echo e($transaction->id); ?>" target="_blank"><?php echo e($transaction->code); ?></a></td>
                                                <td class="text-capitalize"><?php echo e($transaction->payment_method); ?></td>
                                                <td class="text-right"><?php echo e(number_format($transaction->pivot->amount)); ?></td>
                                            </tr>
                                            <?php $subTotal += $transaction->pivot->amount; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="3">Subtotal</td>
                                                <td class="text-right"><?php echo e(number_format($subTotal)); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" style="border-top: none;">Total Penjualan</td>
                                                <td class="text-right" style="border-top: none;"><?php echo e(number_format($centralSale->net_total)); ?></td>
                                            </tr>
                                            <tr style="font-weight: bold;">
                                                <td colspan="3">Sisa Hutang</td>
                                                <td class="text-right"><?php echo e(number_format(abs($subTotal - $centralSale->net_total))); ?></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class="card card-bordered">
                        <div class="card-inner-group">
                            <div class="card-inner card-inner-md">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Riwayat Retur</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="card-inner">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Kode Retur</th>
                                                <th>Metode</th>
                                                <th class="text-right">Quantity</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($return->date); ?></td>
                                                <td><a href="/central-sale-return/show/<?php echo e($return->id); ?>" target="_blank"><?php echo e($return->code); ?></a></td>
                                                <td class="text-capitalize"><?php echo e($return->payment_method); ?></td>
                                                <td class="text-right"><?php echo e($return->quantity); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script>
    let app = new Vue({
        el: '#app',
        data: {
            code: '<?php echo e($centralSale->code); ?>',
            date: '<?php echo e($centralSale->date); ?>',
            shipmentId: '<?php echo e($centralSale->shipment_id); ?>',
            customerId: '<?php echo e($centralSale->customer_id); ?>',
            total_weight: '<?php echo e($centralSale->total_weight); ?>',
            total_cost: '<?php echo e($centralSale->total_cost); ?>',
            subtotal: '<?php echo e($centralSale->subtotal); ?>',
            net_total: '<?php echo e($centralSale->net_total); ?>',
            debt: '<?php echo e($centralSale->debt); ?>',
            discount: '<?php echo e($centralSale->discount); ?>',
            shipping_cost: '<?php echo e($centralSale->shipping_cost); ?>',
            other_cost: '<?php echo e($centralSale->other_cost); ?>',
            detail_other_cost: '<?php echo e($centralSale->detail_other_cost); ?>',
            deposit_customer: '<?php echo e($centralSale->deposit_customer); ?>',
            receipt_1: '<?php echo e($centralSale->receipt_1); ?>',
            receive_1: '<?php echo e($centralSale->receive_1); ?>',
            receipt_2: '<?php echo e($centralSale->receipt_2); ?>',
            receive_2: '<?php echo e($centralSale->receive_2); ?>',
            payment_amount: '<?php echo e($centralSale->payment_amount); ?>',
            remaining_payment: '<?php echo e($centralSale->remaining_payment); ?>',
            recipient: '<?php echo e($centralSale->recipient); ?>',
            address_recipient: '<?php echo e($centralSale->address_recipient); ?>',
            detail: '<?php echo e($centralSale->detail); ?>',
            status: '<?php echo e($centralSale->status); ?>',
        }
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/central-sale/show.blade.php ENDPATH**/ ?>