<?php $__env->startSection('title', 'Vapehitz'); ?>

<?php $__env->startSection('content'); ?>
<a href="/saleretail/create" class="btn btn-success">Tambah Penjualan Barang</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/saleretail/index.blade.php ENDPATH**/ ?>