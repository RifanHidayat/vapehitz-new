<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="../">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <!-- Page Title  -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashlite.css?ver=2.4.0')); ?>">
    <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('assets/css/theme.css?ver=2.4.0')); ?>">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/libs/fontawesome-icons.css')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
    <style>
        /* .dataTables_filter {
        text-align: right;
        width: 90%;
    } */

        /* table tr th {
        font-size: 15px;
       
    }

    table tr td {
        font-size: 13px;
      
    }

        /* .pull-left {
        float: left !important;
    }

    .pull-right {
        float: right !important;
        margin-bottom: 20px;
    }

    .bottom {
        float: right !important;
    } */
        .datatable-wrap {
            border: none;
            /* overflow-x: scroll; */
        }

        /* 
        .table-responsive {
            overflow-x: hidden;
        } */
    </style>
    <?php echo $__env->yieldContent('pagestyle'); ?>
</head>

<body class="nk-body bg-lighter npc-general has-sidebar ">
    <div class="nk-app-root">
        <!-- main @s  -->
        <div class="nk-main">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- wrap @s  -->
            <div class="nk-wrap">
                <!-- main header @s  -->
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- main header @e  -->
                <!-- content @s  -->
                <div class="nk-content" id="app">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e  -->
                <!-- footer @s  -->

                <!-- footer @e  -->
            </div>
            <!-- wrap @e  -->
        </div>
        <!-- main @e  -->
    </div>
    <!-- app-root @e  -->
    <!-- JavaScript -->
    <script src="<?php echo e(asset('assets/js/bundle.js?ver=2.4.0')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js?ver=2.4.0')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/charts/gd-default.js?ver=2.4.0')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
    <?php echo $__env->yieldContent('pagescript'); ?>
</body>

</html><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz-122132131/resources/views/layouts/app.blade.php ENDPATH**/ ?>