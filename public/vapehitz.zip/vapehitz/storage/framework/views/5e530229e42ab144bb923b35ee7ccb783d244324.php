<table>
    <thead>
        <tr>
            <th>No.</th>
            <th>Date</th>
            <th>Created By</th>
            <th>Product</th>
            <th>Qty</th>
            <th>Free</th>
            <th>Price</th>
            <th>Amount</th>
        </tr>
    </thead>
    <tbody>
        <?php $emptyCellCount = 5; ?>
        <?php $total = 0; ?>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $invoiceTotal = 0; ?>
        <tr>
            <td><?php echo e($sale->code); ?></td>
            <td><?php echo e($sale->date); ?></td>
            <?php if($sale->createdBy !== null): ?>
            <td><?php echo e($sale->createdBy->name); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <?php for($i = 0; $i < $emptyCellCount; $i++): ?> <td>
                </td>
                <?php endfor; ?>
        </tr>
        <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td><?php echo e($product->productCategory->name . ':'); ?><?php echo e($product->productSubcategory->name . ' - '); ?><?php echo e($product->name); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->quantity); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->free); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->price); ?></td>
            <?php $amount = $product->pivot->quantity * $product->pivot->price ?>
            <td data-format="#,##0_-"><?php echo e($amount); ?></td>
        </tr>
        <?php $total += $amount ?>
        <?php $invoiceTotal += $amount ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>Total for <?php echo e($sale->code); ?></td>
            <?php for($i = 0; $i < ($emptyCellCount); $i++): ?> <td>
                </td> <?php endfor; ?>
                <td data-format="#,##0_-"><?php echo e($invoiceTotal); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>Total</td>
            <?php for($i = 0; $i < ($emptyCellCount); $i++): ?> <td>
                </td> <?php endfor; ?>
                <td data-format="#,##0_-"><?php echo e($total); ?></td>
        </tr>
    </tbody>
</table><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/report/sales/detail/studio-sale-sheet.blade.php ENDPATH**/ ?>