<table>
    <thead>
        <tr>
            <th>Tanggal</th>
            <th>Deskripsi</th>
            <th>Catatan</th>
            <th>In</th>
            <th>Out</th>
            <th>Saldo</th>
            
        </tr>
    </thead>
    <tbody>
       

        <?php $balance=0; ?>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $transaction->account_type=="in"?$balance+=$transaction->amount:$balance-=$transaction->amount   ?>
        
        <tr>
            <td data-format="#,##0_-" style="width:10%"><?php echo e($transaction->date); ?></td>
            <td style="width:25%" ><?php echo e($transaction->description); ?></td>
            <td style="width:25%"><?php echo e($transaction->note); ?></td>
            <td  style="width:15%">
                <?php echo e($transaction->account_type=="in"
                    ?$transaction->amount
                    :""); ?>

            </td>
            <td>
            <?php echo e($transaction->account_type=="out"
                    ?$transaction->amount
                    :""); ?>

        </td>
            <td style="width:15%"><?php echo e($balance); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </tbody>
</table><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/account/transaction-account-sheet.blade.php ENDPATH**/ ?>