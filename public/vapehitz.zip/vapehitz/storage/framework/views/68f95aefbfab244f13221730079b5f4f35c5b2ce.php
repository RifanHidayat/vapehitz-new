<table>
    <thead>
        <tr>
            <td>Customer</td>
            <td>Date</td>
            <td>No.</td>
            <td>Created By</td>
            <td>Product</td>
            <td>Quantity</td>
            <td>Free</td>
            <td>Price</td>
            <td>Amount</td>
        </tr>
    </thead>
    <tbody>
        <?php $emptyCellCount = 8; ?>
        <?php $__currentLoopData = $sales_by_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer => $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($customer); ?></td>
            <?php for($i = 0; $i < $emptyCellCount; $i++): ?> <td>
                </td>
                <?php endfor; ?>
        </tr>
        <?php $totalByCustomer = 0; ?>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td></td>
            <td><?php echo e($sale->date); ?></td>
            <td><?php echo e($sale->code); ?></td>
            <?php if($sale->createdBy !== null): ?>
            <td><?php echo e($sale->createdBy->name); ?></td>
            <?php else: ?>
            <td>-</td>
            <?php endif; ?>
            <td><?php echo e($product->productCategory->name . ':'); ?><?php echo e($product->productSubcategory->name . ' - '); ?><?php echo e($product->name); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->quantity); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->free); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->price); ?></td>
            <td data-format="#,##0_-"><?php echo e($product->pivot->amount); ?></td>
        </tr>
        <?php $totalByCustomer += $product->pivot->amount ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr style="border-top: 1px solid #000;">
            <td>Total For <?php echo e($customer); ?></td>
            <?php for($i = 0; $i < ($emptyCellCount - 1); $i++): ?> <td>
                </td> <?php endfor; ?>
                <td data-format="#,##0_-"><?php echo e($totalByCustomer); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/report/sales/detail/central-sale-by-customer-sheet.blade.php ENDPATH**/ ?>