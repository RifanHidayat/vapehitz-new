<table>
    <thead>
        <tr>
            <td>Customer</td>
            <td>Total</td>
        </tr>
    </thead>
    <tbody>
        <?php $total = 0; ?>
        <?php $__currentLoopData = $sales_by_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($sale['customer']); ?></td>
            <td data-format="#,##0_-"><?php echo e($sale['total']); ?></td>
        </tr>
        <?php $total += $sale['total'] ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>TOTAL</td>
            <td data-format="#,##0_-"><?php echo e($total); ?></td>
        </tr>
    </tbody>
</table><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/report/sales/summary/central-sale-by-customer-sheet.blade.php ENDPATH**/ ?>