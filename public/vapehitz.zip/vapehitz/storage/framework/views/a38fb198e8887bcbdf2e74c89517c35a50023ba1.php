<table>
    <tr>
        <td>
            PERMINTAAN BARANG KE PUSAT
        </td>
    </tr>
    <tr>
        <td>
            No. <?php echo e($req->code); ?>

        </td>
    </tr>
    <tr>
        <td>
            Date. <?php echo e($req->date); ?>

        </td>
    </tr>
    <tr>
        <td>Product</td>
        <td>Qty</td>
    </tr>
    <?php $__currentLoopData = $req->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e($product->pivot->quantity); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/retail-request-to-central/excel.blade.php ENDPATH**/ ?>