<?php $__env->startSection('title', 'Vapehitz'); ?>

<?php $__env->startSection('content'); ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between g-3">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">Detail Transaksi Pembelian</h3>
            <div class="nk-block-des text-soft">
                <ul class="list-inline">
                    <li>Nomor Order: <span class="text-base"><?php echo e($centralPurchase->code); ?></span></li>
                    <li>Tanggal Order: <span class="text-base"><?php echo e($centralPurchase->date); ?></span></li>
                </ul>
            </div>
        </div>
        <div class="nk-block-head-content">
            <a href="/central-purchase" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em class="icon ni ni-arrow-left"></em><span>Back</span></a>
        </div>
    </div>
</div>
<div class="row g-gs align-items-start">
    <div class="col-lg-6 col-md-12">
        <div class="card card-bordered h-100">
            <div class="card-inner">
                <div class="card-title-group align-start mb-3">
                    <div class="card-title">
                        <h6 class="title">Supplier</h6>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <i class="icon ni ni-layers mr-2" style="font-size: 2em;"></i>
                            <div class="info">
                                <span class="title">Kode</span>
                                <p class="amount"><strong><?php echo e($centralPurchase->supplier->code); ?></strong></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <em class="far fa-building" style="font-size: 2em;margin-right:10px"></em>
                            <div class="info">
                                <span class="title">Nama</span>
                                <p class="text-lg"><strong><?php echo e($centralPurchase->supplier->name); ?></strong></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card card-bordered h-100">
            <div class="card-inner-group">
                <div class="card-inner card-inner-md">
                    <div class="card-title-group">
                        <div class="card-title">
                            <h6 class="title">Detail Produk</h6>
                        </div>
                        <!-- <div class="card-tools mr-n1">
                                <ul class="btn-toolbar gx-1">
                                    <li>
                                        <a class="btn btn-icon btn-trigger" data-toggle="modal" href="#exampleModal" data-backdrop="static" data-keyboard="false"><em class="icon ni ni-plus"></em></a>
                                    </li>
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="#" @click.prevent="removeAllSelectedProducts"><em class="icon ni ni-notify"></em><span>Hapus Semua</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div> -->
                    </div>
                </div><!-- .card-inner -->
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="width: 15%;" align="left">Nomor Produk</th>
                            <th style="width: 20%;" align="left">Nama Produk</th>
                            <th style="width: 15%;" align="right"><b>Harga</b></th>
                            <th style="width: 15%;" align="right"><b>Quantity</b></th>
                            <th style="width: 15%;" align="right"><b>Free</b></th>

                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $centralPurchase->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td class="text-left"><?php echo e($product->code); ?></td>
                            <td class="text-left"><?php echo e($product->name); ?></td>
                            <td class="text-right"><?php echo e(number_format($product->pivot->price)); ?></td>
                            <td class="text-right"><?php echo e($product->pivot->quantity-$product->pivot->return_quantity); ?></td>
                            <td class="text-right"><?php echo e($product->pivot->free); ?></td>
                        </tr>




                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div><!-- .card-inner-group -->
        </div>
    </div>
    <div class="col-lg-6 col-md-12">
        <div class="card card-bordered">
            <div class="card-inner-group">
                <div class="card-inner card-inner-md">
                    <div class="card-title-group">
                        <div class="card-title">
                            <h6 class="title">Detail Pembelian</h6>
                        </div>
                        <!-- <div class="card-tools mr-n1">
                                <div class="drodown">
                                    <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                    <div class="dropdown-menu dropdown-menu-right" style="">
                                        <ul class="link-list-opt no-bdr">
                                            <li><a href="#"><em class="icon ni ni-plus"></em><span>Tambah</span></a></li>
                                            <li><a href="#"><em class="icon ni ni-notify"></em><span>Hapus Semua</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div> -->
                    </div>
                </div><!-- .card-inner -->
                <ul class="is-compact">
                    <li class="data-item">
                        <div class="data-col">
                            <div class="data-label">Biaya Pengiriman</div>
                            <div class="data-value"><?php echo e(number_format($centralPurchase->shipping_cost)); ?></div>
                        </div>
                    </li>
                    <li class="data-item">
                        <div class="data-col">
                            <div class="data-label">Diskon</div>
                            <div class="data-value"><?php echo e(number_format($centralPurchase->discount)); ?></div>
                        </div>
                    </li>
                    <li class="data-item">
                        <div class="data-col">
                            <div class="data-label">Net</div>
                            <div class="data-value" style="text-align: right;"><?php echo e(number_format($centralPurchase->netto)); ?></div>
                        </div>
                    </li>

                    <!-- <li class="data-item">
                        <div class="data-col">
                            <div class="data-label">Total</div>
                            <div class="data-value"><?php echo e(number_format($centralPurchase->total)); ?></div>
                        </div>
                    </li> -->
                    <li class="data-item">
                        <div class="data-col">
                            <div class="data-label">Jumlah Bayar</div>
                            <div class="data-value"><?php echo e(number_format($payAmount)); ?></div>
                        </div>
                    </li>
                    <li class="data-item">
                        <div class="data-col">
                            <div class="data-label">Sisa</div>
                            <div class="data-value"><?php echo e(number_format($centralPurchase->netto-$payAmount)); ?></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card card-bordered">
            <div class="card-inner-group">
                <div class="card-inner card-inner-md">
                    <div class="card-title-group">
                        <div class="card-title">
                            <h6 class="title">Riwayat Pembayaran</h6>
                        </div>
                        <br>
                        <!-- <div class="card-tools mr-n1">
                                <div class="drodown">
                                    <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                    <div class="dropdown-menu dropdown-menu-right" style="">
                                        <ul class="link-list-opt no-bdr">
                                            <li><a href="#"><em class="icon ni ni-plus"></em><span>Tambah</span></a></li>
                                            <li><a href="#"><em class="icon ni ni-notify"></em><span>Hapus Semua</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div> -->
                    </div>
                </div><!-- .card-inner -->
                <br>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Kode Transaksi</th>
                            <th class="text-left">Metode Pembayaran</th>
                            <th class="text-left">Jumlah Pembayaran</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $subTotal = 0; ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($transaction->account_id!="3"): ?>
                        <tr>
                            <td><?php echo e(date_format(date_create($transaction->date), "d/m/Y")); ?></td>
                            <td><a href="/purchase-transaction/show/<?php echo e($transaction->id); ?>" target="_blank"><?php echo e($transaction->code); ?></a></td>
                            <td class="text-left"><?php echo e($transaction->payment_method); ?></td>
                            <td class="text-right"><?php echo e(number_format($transaction->pivot->amount)); ?></td>

                        </tr>
                        <?php $subTotal += $transaction->pivot->amount; ?>
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3">Subtotal</td>
                            <td class="text-right"><?php echo e(number_format($subTotal)); ?></td>
                        </tr>
                        <tr>
                            <td colspan="3" style="border-top: none;">Total Pembelian</td>
                            <td class="text-right" style="border-top: none;"><?php echo e(number_format($centralPurchase->netto)); ?></td>
                        </tr>
                        <tr style="font-weight: bold;">
                            <td colspan="3">Sisa Hutang</td>
                            <td class="text-right"><?php echo e(number_format(abs($subTotal - $centralPurchase->netto))); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div><!-- .card-inner -->


    </div>
</div>
</div>
</div><!-- .nk-block -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagescript'); ?>
<script>
    let app = new Vue({
        el: '#app',
        data: {
            selectedProducts: JSON.parse('<?php echo $centralPurchase->products; ?>'),
            loading: false,
        },
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arenzha/LaravelProjects/vapehitz/resources/views/central-purchase/show.blade.php ENDPATH**/ ?>